//
//  ViewController.swift
//  newQuizApp
//
//  Created by Yifan Lou on 7/4/17.
//  Copyright © 2017 Yifan Lou. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var questions = ["Which is your favorite pet?", "Which is your favorite color?", "Your city?"]
    var answers = [["dog", "cat", "bird"],["blue", "pink", "yellow"],["New York", "Shanghai", "Paris"]]
    var currentQuestion = 0
    var rightAnswerPlacement:UInt32 = 0
    var score = 0
    
    
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func button(_ sender: AnyObject)
    {
        if sender.tag == Int(rightAnswerPlacement)
        {
            print("right!")
            score += 1
        }else{
            print("wrong!!!")
        }
        if currentQuestion != questions.count{
            newQuestion()
        }else{
            performSegue(withIdentifier: "segue", sender: self)
        }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let mySecondViewController = segue.destination as! SecondViewController
        mySecondViewController.myScore = String(score)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        newQuestion()
    }
    
    func newQuestion(){
        label.text = questions[currentQuestion]
        rightAnswerPlacement = arc4random_uniform(3)+1
        
        
        var button:UIButton = UIButton()
        var x = 1
        for i in 1...3
        {
            button = view.viewWithTag(i) as! UIButton
            if i == Int(rightAnswerPlacement)
            {
                button.setTitle(answers[currentQuestion][0], for: .normal)
            }else{
                button.setTitle(answers[currentQuestion][x], for: .normal)
                x = 2
            }
        }
        currentQuestion += 1
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

