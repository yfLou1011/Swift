//
//  ToDoItem.swift
//  superCool-TodoList
//
//  Created by Yifan Lou on 7/14/17.
//  Copyright © 2017 Yifan Lou. All rights reserved.
//

import UIKit

class ToDoItem: NSObject {

    var text:String
    var completed:Bool
    
    
    init(text:String) {
        self.text = text
        self.completed = false
    }
    
    
}
